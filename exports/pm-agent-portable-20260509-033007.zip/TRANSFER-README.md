# PM Agent portable package

Gói này chứa bộ file cốt lõi để mang PM Agent sang máy khác:
- docs/pm-agent/: framework chính của PM Agent
- AGENTS.md, SOUL.md, USER.md, TOOLS.md: persona + workspace conventions
- MEMORY.md và memory/: memory/cấu trúc tri thức để PM Agent giữ ngữ cảnh
- HEARTBEAT.md: heartbeat checklist hiện tại

Không bao gồm:
- node_modules
- source code của project test Web Bán Hàng
- artifact runtime tạm thời

Nếu chỉ muốn chạy PM Agent framework trên máy mới, thường chỉ cần copy các file trong gói này vào workspace mới.
